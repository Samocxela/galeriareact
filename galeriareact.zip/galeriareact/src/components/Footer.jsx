import Badge from 'react-bootstrap/Badge';
function Footer(){
   
    return(
        <footer>
            <h2><Badge bg="dark">Copyrigth @Samocxela</Badge></h2>
            <p>Todos los derechos reservados</p>
           
     
        </footer>
    )
}
export default Footer;